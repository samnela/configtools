SELECT * FROM validdem;

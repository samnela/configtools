select * from wd_win.modetat;
